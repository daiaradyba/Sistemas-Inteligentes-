# Datasets
Nesta pasta, os seguintes arquivos estão disponíveis:
- **env_vital_signals.txt**: utilizado pelo simulador
- **input.txt**: arquivo de entrada para os classificadores com a última coluna fixa em 1 (label de gravidade)
- **target.txt**: arquivo de referência para medir a acurácia dos classificadores


