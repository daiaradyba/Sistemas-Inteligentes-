# Tools for generating synthetic data and checking generated data

*vital_signals_renumber_id_and_stats.py*: renumber the victims' id  starting from zero, print the number of victims per label and the corresponding accumulated severity value.
