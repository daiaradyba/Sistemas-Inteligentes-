This folder contains python programs to show results, the grid, ...

exp_plot_results
----------------
>   Plot results of an experiment containing several runs of VictimSim2.  For each run, the VictimSim2 prints the number of found and saved victims . The user should copy and past these values to a CSV file. From this input file, the program plots histograms of saved/rescued victims per severity  (absolute values and relative to the total number of victims), and the Veg and Vsg metrics.
